
import info.gridworld.actor.Bug;

/**
 * @author Christopher Pybus
 * @date Feb 20, 2012
 * @file BoxBug.java
 * @package Module13._06GridWorldPart2
 * 
 * @purpose 
 */


public class BoxBug extends Bug
{
	
    int sideLength;
	int steps = 0;
	
	public BoxBug(int length)
	{
		sideLength = length;
	}
	
	public void act()
	{
		
		if (steps < sideLength && canMove())
		{
			move();
			steps++;
		}
		else
		{
			turn();
			turn();
			steps = 0;
		}
	}
}
