package Module8._03DefaultConstructors;

/**
 * Name: Christopher Pybus
 * Date: Nov 20, 2011
 * File: Calculations.java
 * Package: Module8._03DefaultConstructors
 * 
 * Purpose: 
 */

public class Calculations
{
	Calculations()
	{
		
	}
	
	public int calcDistance(int sMiles, int eMiles)
	{
		int distance = 0;
		distance = eMiles-sMiles;
		return distance;
	}
	
	public double calcMPG(int distance, double gals)
	{
		double MPG = 0;
		MPG = distance/gals;
		return MPG;
	}
}
