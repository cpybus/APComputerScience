
/**
 * @author Christopher Pybus
 * @date Apr 1, 2012
 * @file Processing.java
 * @package Module15._03Interfaces
 * 
 * @purpose 
 */

public interface Processing
{
	void doReading();
}
