

/**
 * @author Christopher Pybus
 * @date Apr 1, 2012
 * @file Product.java
 * @package Module15._05ChallengeProgram
 * 
 * @purpose 
 */

public interface Product
{
	
	public abstract String getName();
	
	public abstract double getCost();
}
