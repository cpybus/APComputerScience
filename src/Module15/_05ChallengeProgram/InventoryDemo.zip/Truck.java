

/**
 * @author Christopher Pybus
 * @date Apr 1, 2012
 * @file Truck.java
 * @package Module15._05ChallengeProgram
 * 
 * @purpose 
 */

public class Truck extends Vehicle
{

	Truck(String name, double cost)
	{
		super(name, cost);
	}
	
}
