

/**
 * @author Christopher Pybus
 * @date Apr 1, 2012
 * @file Car.java
 * @package Module15._05ChallengeProgram
 * 
 * @purpose 
 */

public class Car extends Vehicle
{

	Car(String name, double cost)
	{
		super(name, cost);
	}
	
}
